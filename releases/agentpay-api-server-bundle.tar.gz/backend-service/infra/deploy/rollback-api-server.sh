#!/usr/bin/env sh
set -eu

APP_DIR="${APP_DIR:-/opt/agentpay/backend-service}"
RELEASES_DIR="${RELEASES_DIR:-/opt/agentpay/releases}"
ROLLBACK_RELEASE="${ROLLBACK_RELEASE:?Set ROLLBACK_RELEASE to a release directory under /opt/agentpay/releases}"

if [ ! -d "$RELEASES_DIR/$ROLLBACK_RELEASE" ]; then
  echo "Release not found: $RELEASES_DIR/$ROLLBACK_RELEASE"
  exit 1
fi

systemctl stop agentpay-api || true
rm -rf "$APP_DIR"
cp -a "$RELEASES_DIR/$ROLLBACK_RELEASE" "$APP_DIR"
chown -R agentpay:agentpay "$APP_DIR"
systemctl start agentpay-api
systemctl status agentpay-api --no-pager
